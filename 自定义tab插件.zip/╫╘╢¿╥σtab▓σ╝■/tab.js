;
$(".tab a").click(function() {
    $(".tab a").removeClass("tab_active");
    $(this).toggleClass("tab_active");
    $(".tab_body .tab_item").removeClass("tab_item_active");
    let index = $(this).index();
    $(".tab_body .tab_item")[index].classList.add("tab_item_active");


})